#ifndef SLIDER_LIB_H
#define SLIDER_LIB_H

#include "adc_lib.h"
	
int read_slider_position(int channel);

#endif