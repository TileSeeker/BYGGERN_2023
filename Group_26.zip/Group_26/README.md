# TTK4155 - Industrielle og innbygde datasystemers konstruksjon


