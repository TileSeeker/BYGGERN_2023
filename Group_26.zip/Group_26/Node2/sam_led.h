#ifndef SAM_LED_H
#define SAM_LED_H

void led_init(void);

#endif