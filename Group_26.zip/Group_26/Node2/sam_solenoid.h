#ifndef SAM_SOLENOID_H
#define SAM_SOLENOID_H

#include "sam.h"
#include "sam_delay.h"

void solenoid_init();


#endif